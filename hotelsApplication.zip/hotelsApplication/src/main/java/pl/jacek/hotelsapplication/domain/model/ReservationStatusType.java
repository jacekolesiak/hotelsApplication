package pl.jacek.hotelsapplication.domain.model;

public enum ReservationStatusType {
    NEW, CANCELED, IN_PROGRESS, FINISHED
}
