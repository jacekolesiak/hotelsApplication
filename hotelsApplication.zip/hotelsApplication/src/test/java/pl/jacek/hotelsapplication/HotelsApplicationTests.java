package pl.jacek.hotelsapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelsApplicationTests {

    @Test
    void contextLoads() {
    }

}
